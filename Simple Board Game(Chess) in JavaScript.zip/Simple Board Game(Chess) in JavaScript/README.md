This is a complete well automated chess game made by object oriented javascript I hope you like it.

Play it from here: https://ahmadalkholy.github.io/Javascript-Chess-Game/chess.html

------------

The chess pieces images are originaly made by <a href="https://pixabay.com/users/Clker-Free-Vector-Images-3736/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=26774" target="_blank">Clker-Free-Vector-Images</a> from <a href="https://pixabay.com/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=26774" target="_blank">Pixabay</a> you can get get it from <a href="https://pixabay.com/vectors/chess-pieces-set-symbols-game-26774/" target="_blank">here</a>.